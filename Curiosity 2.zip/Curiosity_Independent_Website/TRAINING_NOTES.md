# Curiosity model training: what this means

There are three different things that people call "learning":

1. **Saved memory (implemented in the starter):** Curiosity saves explicit memory notes to the user's account and supplies them as context in future prompts. This changes what the model knows about that account, but does not change model weights.
2. **Fine-tuning (not implemented here):** Train an eligible existing model on a carefully curated set of examples so it follows Curiosity's style or handles repeated tasks more consistently. Availability, format, model eligibility, and cost depend on the provider. Use the official provider documentation and get adult help with account/billing.
3. **Training from scratch (not practical for this web app):** Requires a very large dataset, substantial GPU compute, ML expertise, evaluation, and ongoing hosting. Do not expect the website or a browser to train a general-purpose LLM by itself.

Before fine-tuning, collect a small, high-quality, non-private dataset with examples of desired inputs and outputs. Remove names, emails, school records, personal chats, secrets, and anything you do not have permission to use. Keep evaluation examples separate from training examples. Test for accuracy, privacy, prompt injection, and unwanted memorization.

The JSONL file in `training/` is only a formatting example, not enough data to train a useful model. Do not upload it as a production training dataset without reviewing and replacing it.
