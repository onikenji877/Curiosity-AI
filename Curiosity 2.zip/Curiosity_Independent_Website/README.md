# Curiosity — Independent Website

Curiosity is a provider-neutral Node.js website package. It does **not** require Netlify and contains no Netlify branding in the user interface. It serves the site and its own `/api/chat` endpoint from one Node.js process. You can run it on a computer or deploy it to any compatible Node.js host, or your own server with a domain.

## Features in this starter

- Curiosity-branded responsive website using the included Curiosity logo
- Email/password sign-up and sign-in, display name, and password-reset email via Supabase Auth
- User-specific cloud memories stored in Supabase, available across devices when signed into the same account
- Real AI chat through the server-side OpenAI Responses API; API secrets never go into browser code
- Chat history saved to the signed-in account and synced across devices, with a clear-history control
- Add and delete memory notes from the memory page, as well as by saying `Remember that ...` in chat
- Installable, responsive website experience for phones, tablets, and desktops; static shell can be cached for offline opening
- Grades screen that shows **N/A** until verified grade data is provided; its course rows are placeholders, not real student records
- Original bundled website assets and the N/A patch notes are retained under `original_site_assets/` for reference
- Fine-tuning example template and notes

## Before it can run with accounts and AI

This package is a deployable starter, not a magically configured live service. You must create and configure your own Supabase project and AI API credentials. Do not put secrets in the public folder or share them in screenshots or chat. Because API use may cost money, have a parent/guardian help review the provider account and billing before enabling paid AI use.

### 1. Requirements

- Node.js 20 or newer
- A Supabase project
- An enabled model and API key for the OpenAI API

### 2. Configure Supabase

1. Create a Supabase project.
2. Open Supabase SQL Editor and run `supabase/schema.sql`.
3. In Authentication settings, enable email/password and configure email confirmation.
4. Add your future website's exact domain to allowed redirect URLs.
5. Copy the project URL and publishable key.

The publishable key is intended for browser use. Never use a Supabase service-role key in the browser.

### 3. Configure server environment

Copy `.env.example` to `.env` and fill in:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `OPENAI_API_KEY` (server-side secret only)
- `OPENAI_MODEL` (a model enabled for your API account)

Node.js does not automatically read `.env` files in all versions/configurations. For local use, set the variables in your shell or use Node's environment-file option, for example `node --env-file=.env server.mjs`.

### 4. Run locally

```bash
node --env-file=.env server.mjs
```

Open `http://localhost:3000`. The health endpoint is `http://localhost:3000/api/health`.

### 5. Publish independently

Upload the project to any Node.js host or your own server. Set the same four environment variables in that host's **server-side secret/environment settings** and use `npm start` (or `node server.mjs`) as the start command. Point your custom domain's DNS to that host. The site itself does not display hosting-provider branding. A domain and hosting may have separate costs.

### Add Curiosity to an iPhone or iPad

Once the website is published over HTTPS, open its address in Safari, tap **Share**, then choose **Add to Home Screen**. The app uses a responsive layout and a web-app manifest. Keep in mind that cloud features and AI chat need an internet connection.

## Privacy and limitations

- Memories are stored per account and protected by Supabase Row Level Security. Test with two separate accounts before storing real data.
- Chat history and saved memories are stored as private per-user JSON data in Supabase. The interface keeps the most recent 100 chat messages (50 exchanges); each AI request receives only a short recent history to control context size. Clearing history removes it from the account.
- Offline caching only keeps the website shell available. Sign-in, cloud data, and AI chat still require an internet connection.
- This starter uses an existing hosted LLM. Memories are context, not model training. `TRAINING_NOTES.md` explains safe, optional fine-tuning concepts.
- Rate limiting is a small per-process safeguard, not a production-grade distributed abuse prevention system. Add stronger rate limits, usage caps, monitoring, and backups before opening it widely.
- The included Grades screen deliberately displays N/A and placeholder course rows. It does not import actual school records.
- The original upload contained minified built assets rather than the editable source project. This package creates an independent Curiosity UI and retains those assets in `original_site_assets/`; it does not pretend the old bundled planner's internal code has been reconstructed or fully integrated.
