import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const $ = (id) => document.getElementById(id);
const config = window.CURIOSITY_CONFIG || {};
let supabase = null, signUpMode = false, history = [], busy = false, toastTimer, activeUserId = null;
const MAX_SAVED_MESSAGES = 100;
const authScreen = $('auth-screen'), app = $('app'), authMessage = $('auth-message');

function setStatus(message, success=false) { authMessage.textContent = message || ''; authMessage.classList.toggle('success', success); }
function toast(message) { const el=$('toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),3200); }
function showAuth() { authScreen.classList.remove('hidden'); app.classList.add('hidden'); }
function showApp(user) {
  authScreen.classList.add('hidden'); app.classList.remove('hidden');
  const name = user.user_metadata?.display_name || user.email?.split('@')[0] || 'Curiosity user';
  $('user-name').textContent=name; $('user-email').textContent=user.email || ''; $('avatar').textContent=name.slice(0,1).toUpperCase();
  if (activeUserId !== user.id) {
    activeUserId = user.id;
    history = [];
    loadChatHistory();
    loadMemories();
    loadTasks();
  }
}
function setAuthMode(signup) {
  signUpMode=signup; $('tab-signin').classList.toggle('active',!signup); $('tab-signup').classList.toggle('active',signup);
  $('name-label').classList.toggle('hidden',!signup); $('display-name').required=signup;
  $('auth-submit').innerHTML=signup?'Create account <span>→</span>':'Sign in <span>→</span>';
  $('forgot-password').classList.toggle('hidden',signup); $('password').autocomplete=signup?'new-password':'current-password'; setStatus('');
}
function addBubble(role, content, error=false) {
  const welcome=$('messages').querySelector('.welcome-message'); if(welcome) welcome.remove();
  const el=document.createElement('div'); el.className=`bubble ${role}${error?' error':''}`; el.textContent=content; $('messages').appendChild(el); $('messages').scrollTop=$('messages').scrollHeight; return el;
}
function renderWelcome() {
  $('messages').innerHTML=''; const welcome=document.createElement('div'); welcome.className='welcome-message';
  welcome.innerHTML='<div class="sparkle">✳</div><h3>What are we curious about?</h3><p>Ask a question, brainstorm an idea, or plan something new.</p><div class="suggestions"><button data-prompt="Help me understand a tricky school topic step by step.">📚 Explain a topic</button><button data-prompt="Help me organize my week into a simple plan.">🗓️ Plan my week</button><button data-prompt="Let’s brainstorm a creative project idea.">💡 Brainstorm ideas</button></div>';
  $('messages').appendChild(welcome);
}
function renderHistory() {
  $('messages').innerHTML = '';
  if (!history.length) { renderWelcome(); return; }
  history.forEach(item => addBubble(item.role, item.content));
}
async function loadChatHistory() {
  if (!supabase) return;
  const host = $('messages');
  host.innerHTML = '<div class="empty-state">Loading your conversation…</div>';
  const { data, error } = await supabase.from('user_data').select('data_value').eq('data_key','chat_history').maybeSingle();
  if (error) {
    renderWelcome();
    toast('Could not sync chat history. Check your database setup.');
    return;
  }
  history = Array.isArray(data?.data_value) ? data.data_value.filter(item => item && ['user','assistant'].includes(item.role) && typeof item.content === 'string').slice(-MAX_SAVED_MESSAGES) : [];
  renderHistory();
}
async function saveChatHistory() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Please sign in again.');
  const { error } = await supabase.from('user_data').upsert({ user_id:user.id, data_key:'chat_history', data_value:history.slice(-MAX_SAVED_MESSAGES), updated_at:new Date().toISOString() }, { onConflict:'user_id,data_key' });
  if (error) throw error;
}
async function clearChatHistory() {
  if (!supabase || busy) return;
  if (!confirm('Clear this conversation from your account on all devices? This cannot be undone.')) return;
  try {
    history = [];
    await saveChatHistory();
    renderWelcome();
    toast('Conversation history cleared.');
  } catch {
    toast('Could not clear chat history. Please try again.');
    await loadChatHistory();
  }
}
async function loadMemories() {
  const host=$('memory-list'); host.innerHTML='<div class="empty-state">Loading your memories…</div>';
  if(!supabase) return;
  const {data,error}=await supabase.from('user_data').select('data_value').eq('data_key','memories').maybeSingle();
  if(error) { host.innerHTML='<div class="empty-state">Could not load memories. Confirm that the Supabase schema has been installed.</div>'; return; }
  const memories=Array.isArray(data?.data_value)?data.data_value.filter(x=>typeof x==='string'):[];
  host.innerHTML='';
  if(!memories.length) { host.innerHTML='<div class="empty-state">No saved memories yet. In chat, tell Curiosity “Remember that…” to add one.</div>'; return; }
  memories.forEach((memory,index)=>{
    const row=document.createElement('div'); row.className='memory-item'; const p=document.createElement('p'); p.textContent=memory;
    const del=document.createElement('button'); del.className='delete-memory'; del.textContent='Delete'; del.addEventListener('click',()=>deleteMemory(index,memories)); row.append(p,del); host.appendChild(row);
  });
}
async function loadTasks() {
  const host=$('task-list'); if(!host) return; host.innerHTML='<div class="empty-state">Loading your planner…</div>';
  if(!supabase) return;
  const {data,error}=await supabase.from('user_data').select('data_value').eq('data_key','planner_tasks').maybeSingle();
  if(error) { host.innerHTML='<div class="empty-state">Could not load tasks. Confirm the Supabase schema is installed.</div>'; return; }
  const tasks=Array.isArray(data?.data_value)?data.data_value.filter(t=>t&&typeof t.title==='string'):[];
  host.innerHTML='';
  if(!tasks.length) { host.innerHTML='<div class="empty-state">Your planner is clear. Add a task above to get started.</div>'; return; }
  tasks.sort((a,b)=>Number(Boolean(a.done))-Number(Boolean(b.done)) || String(a.due||'9999').localeCompare(String(b.due||'9999')));
  tasks.forEach(task=>{
    const row=document.createElement('div'); row.className='task-row'+(task.done?' task-done':'');
    const check=document.createElement('input'); check.type='checkbox'; check.checked=Boolean(task.done); check.setAttribute('aria-label','Mark task complete'); check.addEventListener('change',()=>updateTask(task.id,{done:check.checked}));
    const main=document.createElement('div'); main.className='task-main'; const title=document.createElement('strong'); title.textContent=task.title; main.appendChild(title);
    if(task.due){const due=document.createElement('span');due.className='task-due';due.textContent='Due '+task.due;main.appendChild(due);}
    const del=document.createElement('button');del.className='delete-memory';del.textContent='Delete';del.addEventListener('click',()=>removeTask(task.id));row.append(check,main,del);host.appendChild(row);
  });
}
async function getTasks() {
  const {data,error}=await supabase.from('user_data').select('data_value').eq('data_key','planner_tasks').maybeSingle();
  if(error) throw error; return Array.isArray(data?.data_value)?data.data_value:[];
}
async function saveTasks(tasks) {
  const {data:{user}}=await supabase.auth.getUser(); if(!user) throw new Error('Please sign in again.');
  const {error}=await supabase.from('user_data').upsert({user_id:user.id,data_key:'planner_tasks',data_value:tasks,updated_at:new Date().toISOString()},{onConflict:'user_id,data_key'}); if(error) throw error;
}
async function updateTask(id, patch) { try { const tasks=await getTasks(); await saveTasks(tasks.map(t=>t.id===id?{...t,...patch}:t)); loadTasks(); } catch { toast('Could not update that task.'); } }
async function removeTask(id) { try { const tasks=await getTasks(); await saveTasks(tasks.filter(t=>t.id!==id)); toast('Task deleted.'); loadTasks(); } catch { toast('Could not delete that task.'); } }
$('task-form')?.addEventListener('submit',async e=>{
  e.preventDefault(); const title=$('task-title').value.trim(); if(!title||!supabase) return;
  const button=$('task-form').querySelector('button'); button.disabled=true;
  try { const tasks=await getTasks(); tasks.push({id:crypto.randomUUID(),title,due:$('task-date').value||'',done:false,createdAt:new Date().toISOString()}); await saveTasks(tasks); $('task-title').value=''; $('task-date').value=''; toast('Task saved to your planner.'); loadTasks(); }
  catch { toast('Could not save task. Check your Supabase setup.'); } finally { button.disabled=false; }
});
$('refresh-tasks')?.addEventListener('click',loadTasks);
async function addMemory(value) {
  const memory = value.trim();
  if (!memory || !supabase) return;
  if (memory.length > 500) { toast('Keep each memory under 500 characters.'); return; }
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Please sign in again.');
    const { data, error } = await supabase.from('user_data').select('data_value').eq('data_key','memories').maybeSingle();
    if (error) throw error;
    const memories = Array.isArray(data?.data_value) ? data.data_value.filter(x => typeof x === 'string') : [];
    if (memories.some(item => item.toLowerCase() === memory.toLowerCase())) { toast('That memory is already saved.'); return; }
    memories.push(memory);
    const { error: saveError } = await supabase.from('user_data').upsert({ user_id:user.id, data_key:'memories', data_value:memories.slice(-100), updated_at:new Date().toISOString() }, { onConflict:'user_id,data_key' });
    if (saveError) throw saveError;
    $('memory-input').value = '';
    toast('Memory saved to your account.');
    loadMemories();
  } catch {
    toast('Could not save that memory. Check your database setup.');
  }
}
async function deleteMemory(index, memories) {
  const next=memories.filter((_,i)=>i!==index);
  const {error}=await supabase.from('user_data').upsert({user_id:(await supabase.auth.getUser()).data.user.id,data_key:'memories',data_value:next,updated_at:new Date().toISOString()},{onConflict:'user_id,data_key'});
  if(error) { toast('Could not delete that memory.'); return; } toast('Memory deleted.'); loadMemories();
}
async function sendMessage(text) {
  if(!supabase || busy || !text.trim()) return;
  const message=text.trim(); busy=true; $('chat-input').value=''; $('chat-input').disabled=true;
  addBubble('user',message); const pending=addBubble('assistant','Curiosity is thinking…'); $('chat-form').querySelector('button[type="submit"]').disabled=true;
  try {
    const {data:{session}}=await supabase.auth.getSession(); if(!session) throw new Error('Your session expired. Please sign in again.');
    const response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${session.access_token}`},body:JSON.stringify({message,history})});
    const result=await response.json().catch(()=>({})); if(!response.ok) throw new Error(result.error||'Curiosity could not answer right now.');
    pending.textContent=result.text; history.push({role:'user',content:message},{role:'assistant',content:result.text}); history=history.slice(-MAX_SAVED_MESSAGES);
    try { await saveChatHistory(); } catch { toast('Reply received, but chat history could not sync.'); }
    if(result.memorySaved) { toast('Saved to your memories.'); loadMemories(); }
  } catch(error) { pending.classList.add('error'); pending.textContent=error.message||'Something went wrong.'; }
  finally { busy=false; $('chat-input').disabled=false; $('chat-form').querySelector('button[type="submit"]').disabled=false; $('chat-input').focus(); }
}
function navigate(page) {
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active-page',p.id===`page-${page}`));
  const titles={chat:['YOUR PERSONAL AI','AI Chat'],planner:['YOUR PERSONAL SPACE','Planner'],memory:['YOUR PERSONAL SPACE','My Memory'],grades:['YOUR SCHOOL SPACE','Grades']};
  $('page-kicker').textContent=titles[page][0]; $('page-title').textContent=titles[page][1];
  if(page==='memory') loadMemories(); if(page==='planner') loadTasks();
}

$('tab-signin').addEventListener('click',()=>setAuthMode(false)); $('tab-signup').addEventListener('click',()=>setAuthMode(true));
$('auth-form').addEventListener('submit',async e=>{
  e.preventDefault(); if(!supabase) return setStatus('Setup needed: add your Supabase URL and publishable key to the server environment.');
  setStatus(''); $('auth-submit').disabled=true;
  const email=$('email').value.trim(), password=$('password').value, name=$('display-name').value.trim();
  try {
    if(signUpMode) {
      const {data,error}=await supabase.auth.signUp({email,password,options:{data:{display_name:name}}}); if(error) throw error;
      if(data.session) { setStatus('Account created!',true); } else { setStatus('Account created! Check your email to confirm, then sign in.',true); setAuthMode(false); }
    } else { const {error}=await supabase.auth.signInWithPassword({email,password}); if(error) throw error; }
  } catch(error) { setStatus(error.message||'Could not complete sign-in.'); }
  finally { $('auth-submit').disabled=false; }
});
$('forgot-password').addEventListener('click',async()=>{
  if(!supabase) return setStatus('Add your Supabase settings first.'); const email=$('email').value.trim(); if(!email) return setStatus('Enter your email address first.');
  const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:location.origin}); setStatus(error?error.message:'If the email is registered, a password reset link will arrive shortly.',!error);
});
$('signout').addEventListener('click',async()=>{await supabase?.auth.signOut();activeUserId=null;history=[];renderWelcome();showAuth();});
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.page)));
document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.goto)));
$('refresh-memories').addEventListener('click',loadMemories);
$('memory-form').addEventListener('submit',e=>{e.preventDefault();addMemory($('memory-input').value);});
$('clear-chat').addEventListener('click',clearChatHistory);
$('chat-form').addEventListener('submit',e=>{e.preventDefault();sendMessage($('chat-input').value);});
$('messages').addEventListener('click',e=>{const b=e.target.closest('[data-prompt]');if(b){$('chat-input').value=b.dataset.prompt;sendMessage(b.dataset.prompt);}});
$('chat-input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('chat-form').requestSubmit();}});

if(config.supabaseUrl && config.supabasePublishableKey) {
  supabase=createClient(config.supabaseUrl,config.supabasePublishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  supabase.auth.onAuthStateChange((_event,session)=>{if(session?.user) showApp(session.user); else { activeUserId=null; history=[]; renderWelcome(); showAuth(); }});
  const {data:{session}}=await supabase.auth.getSession(); if(session?.user) showApp(session.user); else showAuth();
} else {
  showAuth(); setStatus('Setup needed: configure Supabase in the server environment.');
}

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}
